#!/usr/bin/env python3
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float32MultiArray

ORDER = ["RF", "RR", "LF", "LR"]
PIVOT_JOINTS = {"RF": "front_right_pivot_joint", "RR": "back_right_pivot_joint",
                "LF": "front_left_pivot_joint", "LR": "back_left_pivot_joint"}
WHEEL_JOINTS = {"RF": "front_right_wheel_joint", "RR": "back_right_wheel_joint",
                "LF": "front_left_wheel_joint", "LR": "back_left_wheel_joint"}
SUS_JOINTS = ["left_sus_arm_joint", "right_sus_arm_joint"]


def counts_to_joint(count, offset, counts_per_rev, pivot_sign):
    diff = (count - offset) % counts_per_rev
    if diff > counts_per_rev / 2.0:
        diff -= counts_per_rev
    steer = diff * 2.0 * math.pi / counts_per_rev
    return pivot_sign * steer

class PivotJointStates(Node):
    def __init__(self):
        super().__init__("pivot_joint_states")
        d = self.declare_parameter
        self.offsets = [float(v) for v in d("zero_offsets", [2308, 568, 1395, 2343]).value]
        self.cpr = float(d("counts_per_rev", 4096).value)
        self.sign = float(d("pivot_sign", -1.0).value)
        rate = float(d("rate", 30.0).value)

        self.q = [0.0] * 4
        self.names = ([PIVOT_JOINTS[w] for w in ORDER] + [WHEEL_JOINTS[w] for w in ORDER] + SUS_JOINTS)

        self.create_subscription(Float32MultiArray, "pivot_encoders", self.on_enc, 10)
        self.pub = self.create_publisher(JointState, "joint_states", 10)
        self.create_timer(1.0 / rate, self.on_timer)
        self.get_logger().info("pivot_joint_states: /pivot_encoders (%s) -> /joint_states" % ", ".join(ORDER))

    def on_enc(self, msg):
        for k in range(min(4, len(msg.data))):
            c = float(msg.data[k])
            if c != c or c < 0.0 or c >= self.cpr:
                self.get_logger().warn("ignoring invalid encoder value %s for %s" % (c, ORDER[k]),
                                       throttle_duration_sec=5.0)
                continue
            self.q[k] = counts_to_joint(c, self.offsets[k], self.cpr, self.sign)

    def on_timer(self):
        js = JointState()
        js.header.stamp = self.get_clock().now().to_msg()
        js.name = self.names
        js.position = self.q + [0.0] * 6
        self.pub.publish(js)


def main():
    rclpy.init()
    node = PivotJointStates()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
