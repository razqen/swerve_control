1. micro_ros agents
2. python3 controller_sh.py --ros-args -p max_angular_accel:=0.3
3. ros2 launch autonav real.launch.py rviz:=true
4. ros2 run teleop_twist_keyboard teleop_twist_keyboard

Checks:
- Turn the pivots; the RViz pivots should follow the real wheels. If mirrored, flip `pivot_sign`.
- `ros2 topic echo /joint_states --once` lists all 10 joints;
- `ros2 topic echo /wheel_speeds` and `/target_angles` match what the wheels do.

Stop `real.launch.py`, then:

5. Do not run `static_transform_publisher`; the URDF provides that transform
   ros2 launch realsense2_camera rs_launch.py \
     depth_module.depth_profile:=640x480x30 rgb_camera.color_profile:=640x480x30 \
     align_depth.enable:=true pointcloud.enable:=true

6. relaunch (add `camera_x:=… camera_z:=… camera_pitch:=…` if the mount differs from 28 cm forward, 0.3575 m up, level):
   ros2 launch autonav real.launch.py rviz:=true

Checks:
- `ros2 topic hz /rtabmap/odom`
- `ros2 topic echo /rtabmap/odom_info --field lost` stays false
- `ros2 run tf2_ros tf2_echo odom base_footprint` changes as you push the rover
- `ros2 topic hz /scan --qos-reliability best_effort`; in RViz show `/scan` with Reliability = Best Effort
- Show the camera cloud in the `base_footprint` frame: the floor should sit flat at z≈0. If tilted, tell me the angle.


7. Stop the controller and `real.launch.py`.
8. Relaunch
   ros2 launch autonav real.launch.py collision_monitor:=true nav2:=true rviz:=true

9. Controller on the safe topic:
   python3 controller_sh.py --ros-args -r /cmd_vel:=/cmd_vel_safe -p max_angular_accel:=0.3

   If the rover won't move, check `/scan` first (the monitor likely stops the rover when `/scan` is stale).

10. Send a goal with the RViz 2D Goal Pose tool, 1 to 2 m ahead. Fixed frame is `map`.

Notes:
- Each start deletes the RTAB-Map database. Use `localization:=true` to reuse `~/rtabmap.db`.
- Stop in reverse order, controller first.
