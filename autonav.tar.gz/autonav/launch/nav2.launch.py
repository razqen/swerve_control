"""Nav2: controller / planner / behaviors / bt_navigator.
Started by `sim.launch.py nav2:=true` / `real.launch.py nav2:=true`, or run on its own once the sim is up.

  slam:=false (default)  no map; everything in the odom frame, map->odom is a static identity   (nav2_params.yaml)
  slam:=true             map-based: global frame = map, map->odom comes from RTAB-Map            (nav2_params_slam.yaml)
  odom_topic:=/odom      odometry topic Nav2 reads velocity from (/rtabmap/odom when RTAB-Map visual odometry is used)
  use_sim_time:=true     set false on the real rover (real.launch.py does this)
  params_file:=<path>    use this yaml instead of the packaged one (real.launch.py passes a copy with use_sim_time false)
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

PKG = "autonav"

def setup(context):
    cfg = os.path.join(get_package_share_directory(PKG), "config")
    slam = LaunchConfiguration("slam").perform(context).lower() == "true"
    use_sim = LaunchConfiguration("use_sim_time").perform(context).lower() == "true"
    odom_topic = LaunchConfiguration("odom_topic").perform(context)
    params = (LaunchConfiguration("params_file").perform(context)
              or os.path.join(cfg, "nav2_params_slam.yaml" if slam else "nav2_params.yaml"))
    sim_time = {"use_sim_time": use_sim}
    bt_params = {
        "default_nav_to_pose_bt_xml": os.path.join(cfg, "navigate_to_pose.xml"),
        "default_nav_through_poses_bt_xml": os.path.join(cfg, "navigate_through_poses.xml"),
        "odom_topic": odom_topic,
    }
    odom_remap = [("odom", odom_topic)]

    def nav_node(pkg, exe, remap=None):
        return Node(package=pkg, executable=exe, name=exe, output="screen", parameters=[params, sim_time],
                    remappings=remap or [])

    actions = []
    if not slam:
        actions.append(Node(package="tf2_ros", executable="static_transform_publisher", name="map_to_odom",
                            arguments=["--x", "0", "--y", "0", "--z", "0", "--roll", "0", "--pitch", "0",
                                       "--yaw", "0", "--frame-id", "map", "--child-frame-id", "odom"],
                            parameters=[sim_time]))
    actions += [
        nav_node("nav2_controller", "controller_server", odom_remap),
        nav_node("nav2_planner", "planner_server"),
        nav_node("nav2_behaviors", "behavior_server"),
        Node(package="nav2_bt_navigator", executable="bt_navigator", name="bt_navigator", output="screen",
             parameters=[params, bt_params, sim_time], remappings=odom_remap),
        Node(package="nav2_lifecycle_manager", executable="lifecycle_manager", name="lifecycle_manager_navigation",
             output="screen",
             parameters=[{"use_sim_time": use_sim, "autostart": True,
                          "node_names": ["controller_server", "planner_server", "behavior_server", "bt_navigator"]}]),
    ]
    return actions


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument("slam", default_value="false"),
        DeclareLaunchArgument("odom_topic", default_value="/odom"),
        DeclareLaunchArgument("use_sim_time", default_value="true"),
        DeclareLaunchArgument("params_file", default_value=""),
        OpaqueFunction(function=setup),
    ])
