"""REAL rover bring-up (no Gazebo, no ros2_control, wall-clock time everywhere).

Starts: robot model (URDF + joint states from /pivot_encoders), RTAB-Map with visual odometry,
pointcloud_to_laserscan -> /scan, and optionally the collision monitor, Nav2 and RViz.

TF (one publisher per edge):
  map -> odom                 RTAB-Map
  odom -> base_footprint      RTAB-Map visual odometry (frame_id = base_footprint, as in the sim)
  base_footprint -> base_link -> ... -> wheels, camera_link     robot_state_publisher (URDF + /joint_states)
  camera_link -> camera_*_optical_frame                          RealSense driver

  ros2 launch autonav real.launch.py
  ros2 launch ... real.launch.py camera_x:=0.28 camera_z:=0.3575 camera_pitch:=0.0
  ros2 launch ... real.launch.py localization:=true          # reuse database_path
  ros2 launch ... real.launch.py collision_monitor:=true nav2:=true
"""
import os
import tempfile

from ament_index_python.packages import (PackageNotFoundError, get_package_prefix,
                                         get_package_share_directory)
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription, OpaqueFunction
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, FindExecutable, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

PKG = "autonav"

def have_pkg(name):
    try:
        get_package_prefix(name)
        return True
    except PackageNotFoundError:
        return False


def setup(context):
    share = get_package_share_directory(PKG)
    prefix = get_package_prefix(PKG)
    lc = lambda n: LaunchConfiguration(n).perform(context)
    flag = lambda n: lc(n).lower() == "true"

    localization, monitor, nav2_on = flag("localization"), flag("collision_monitor"), flag("nav2")

    for pkg in ("rtabmap_launch", "pointcloud_to_laserscan"):
        if not have_pkg(pkg):
            raise RuntimeError("real.launch.py needs ros-jazzy-%s (sudo apt install ros-jazzy-%s)"
                               % (pkg.replace("_", "-"), pkg.replace("_", "-")))
    if monitor and not have_pkg("nav2_collision_monitor"):
        raise RuntimeError("collision_monitor:=true needs ros-jazzy-nav2-collision-monitor")

    def real_copy(name):
        """Copy of config/<name> with use_sim_time forced off (the packaged files are tuned for the sim)."""
        text = open(os.path.join(share, "config", name)).read().replace("use_sim_time: true", "use_sim_time: false")
        dst = os.path.join(tempfile.gettempdir(), "rover_real_" + name)
        with open(dst, "w") as fh:
            fh.write(text)
        return dst

    # robot model
    cam_xyz = "%s %s %s" % (lc("camera_x"), lc("camera_y"), lc("camera_z"))
    cam_rpy = "%s %s %s" % (lc("camera_roll"), lc("camera_pitch"), lc("camera_yaw"))
    xacro_cmd = [FindExecutable(name="xacro"), " ", os.path.join(share, "urdf", "rover.urdf.xacro"),
                 " camera_xyz:='%s' camera_rpy:='%s'" % (cam_xyz, cam_rpy)]
    robot_description = ParameterValue(Command(xacro_cmd), value_type=str)
    rsp = Node(package="robot_state_publisher", executable="robot_state_publisher", output="screen",
               parameters=[{"robot_description": robot_description, "use_sim_time": False}])

    joint_states = ExecuteProcess(
        cmd=["python3", os.path.join(prefix, "lib", PKG, "pivot_joint_states.py"),
             "--ros-args", "-p", "use_sim_time:=false"],
        output="screen")

    actions = [rsp, joint_states]

    # RTAB-Map (visual odometry + map)
    # same arguments as before, except frame_id (base_footprint = ground frame, as in the sim)
    rtab_args = "--Grid/RangeMax 4.0 --Grid/CellSize 0.05 --Grid/MaxObstacleHeight 1.5"
    rtab_args = ("-localization " if localization else "--delete_db_on_start ") + rtab_args
    if lc("rtabmap_extra_args"):
        rtab_args += " " + lc("rtabmap_extra_args")
    rtab = {
        "frame_id": "base_footprint",
        "rgb_topic": "/camera/camera/color/image_raw",
        "depth_topic": "/camera/camera/aligned_depth_to_color/image_raw",
        "camera_info_topic": "/camera/camera/color/camera_info",
        "approx_sync": "true", "qos": "1", "queue_size": "30", "wait_imu_to_init": "false",
        "use_sim_time": "false", "rtabmap_viz": lc("rtabmap_viz"), "rviz": "false",
        "database_path": lc("database_path"), "args": rtab_args,
    }
    actions.append(IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rtabmap_launch"),
                                                   "launch", "rtabmap.launch.py")),
        launch_arguments=rtab.items()))

    # /scan (target frame = ground frame)
    actions.append(Node(
        package="pointcloud_to_laserscan", executable="pointcloud_to_laserscan_node", name="pointcloud_to_laserscan",
        output="screen",
        remappings=[("cloud_in", "/camera/camera/depth/color/points"), ("scan", "/scan")],
        parameters=[{"target_frame": "base_footprint", "min_height": 0.05, "max_height": 0.5,
                     "range_min": 0.3, "range_max": 4.0, "use_inf": True,
                     "transform_tolerance": 0.1, "use_sim_time": False}]))

    # collision monitor (/cmd_vel -> /cmd_vel_safe)
    if monitor:
        actions += [
            Node(package="nav2_collision_monitor", executable="collision_monitor", name="collision_monitor",
                 output="screen", parameters=[real_copy("collision_monitor.yaml")]),
            Node(package="nav2_lifecycle_manager", executable="lifecycle_manager",
                 name="lifecycle_manager_collision_monitor", output="screen",
                 parameters=[{"use_sim_time": False, "autostart": True, "node_names": ["collision_monitor"]}])]

    # Nav2 on the RTAB-Map map
    if nav2_on:
        actions.append(IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(share, "launch", "nav2.launch.py")),
            launch_arguments={"slam": "true", "odom_topic": "/rtabmap/odom", "use_sim_time": "false",
                              "params_file": real_copy("nav2_params_slam.yaml")}.items()))

    actions.append(Node(package="rviz2", executable="rviz2", arguments=["-d", os.path.join(share, "rviz", "rover.rviz")],
                        output="screen", parameters=[{"use_sim_time": False}],
                        condition=IfCondition(LaunchConfiguration("rviz"))))
    return actions


def generate_launch_description():
    D = DeclareLaunchArgument
    return LaunchDescription([
        # camera pose in base_link (centre of the 4 wheels, axle height = 0.1025 m above ground): metres / radians.
        # measured: 0.28 m forward; 0.46 m above ground -> 0.46 - 0.1025 = 0.3575 above base_link; pitch > 0 = nose down
        D("camera_x", default_value="0.28"), D("camera_y", default_value="0.0"), D("camera_z", default_value="0.3575"),
        D("camera_roll", default_value="0.0"), D("camera_pitch", default_value="0.0"), D("camera_yaw", default_value="0.0"),
        D("localization", default_value="false", description="reuse database_path instead of starting a new map"),
        D("database_path", default_value=os.path.expanduser("~/rtabmap.db")),
        D("rtabmap_viz", default_value="false"),
        D("rtabmap_extra_args", default_value="", description="extra RTAB-Map '--Param value' args"),
        D("collision_monitor", default_value="false",
          description="start the collision monitor; then run the controller with -r /cmd_vel:=/cmd_vel_safe"),
        D("nav2", default_value="false", description="also start Nav2 (map-based, nav2_params_slam.yaml)"),
        D("rviz", default_value="false"),
        OpaqueFunction(function=setup),
    ])
