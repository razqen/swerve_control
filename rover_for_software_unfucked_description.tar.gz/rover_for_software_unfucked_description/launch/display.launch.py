"""RViz-only view of the model with sliders for every joint (no Gazebo).

  ros2 launch rover_for_software_unfucked_description display.launch.py
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import Command, FindExecutable
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

PKG = "rover_for_software_unfucked_description"


def generate_launch_description():
    share = get_package_share_directory(PKG)
    xacro_file = os.path.join(share, "urdf", "rover.urdf.xacro")
    robot_description = ParameterValue(Command([FindExecutable(name="xacro"), " ", xacro_file]), value_type=str)
    return LaunchDescription([
        Node(package="robot_state_publisher", executable="robot_state_publisher",
             parameters=[{"robot_description": robot_description}]),
        Node(package="joint_state_publisher_gui", executable="joint_state_publisher_gui"),
        Node(package="rviz2", executable="rviz2", output="screen",
             arguments=["-d", os.path.join(share, "rviz", "rover.rviz"), "-f", "base_footprint"]),
    ])
