"""Gazebo Fortress + ros2_control + swerve controller + RViz (+ optional Nav2, optional RTAB-Map SLAM).

  ros2 launch rover_for_software_unfucked_description sim.launch.py                    # drive with /cmd_vel
  ros2 launch ... sim.launch.py nav2:=true                                            # Nav2, odom frame, no map
  ros2 launch ... sim.launch.py world:=textured slam:=true nav2:=true                 # RTAB-Map + /scan + Nav2 on the map
  ros2 launch ... sim.launch.py world:=textured slam:=true odom_mode:=visual          # RTAB-Map visual odometry
  ros2 launch ... sim.launch.py world:=textured slam:=true localization:=true         # reuse the saved database

world: "obstacles" | "textured" (names of files in worlds/) or a full path to an .sdf
"""
import os
import tempfile

from ament_index_python.packages import (PackageNotFoundError, get_package_prefix,
                                         get_package_share_directory)
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, ExecuteProcess, IncludeLaunchDescription,
                            OpaqueFunction, RegisterEventHandler, SetEnvironmentVariable)
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PythonExpression
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

PKG = "rover_for_software_unfucked_description"


def have_pkg(name):
    try:
        get_package_prefix(name)
        return True
    except PackageNotFoundError:
        return False


def setup(context):
    share = get_package_share_directory(PKG)
    ros_gz = get_package_share_directory("ros_gz_sim")
    lc = lambda n: LaunchConfiguration(n).perform(context)          # noqa: E731
    flag = lambda n: lc(n).lower() == "true"                        # noqa: E731

    slam, nav2_on, localization = flag("slam"), flag("nav2"), flag("localization")
    odom_mode = lc("odom_mode")
    if odom_mode not in ("wheel", "visual"):
        raise RuntimeError("odom_mode must be 'wheel' or 'visual'")

    # ------------------------------------------------------------------ world (@SHARE@ -> install path)
    world = lc("world")
    if not os.path.isfile(world):
        world = os.path.join(share, "worlds", world if world.endswith(".sdf") else world + ".sdf")
    world_name = lc("world_name") or os.path.splitext(os.path.basename(world))[0]
    text = open(world).read().replace("@SHARE@", share)
    world_tmp = os.path.join(tempfile.gettempdir(), "rover_sim_%s.sdf" % world_name)
    with open(world_tmp, "w") as fh:
        fh.write(text)

    controllers = os.path.join(share, "config", "controllers.yaml")
    swerve_yaml = os.path.join(share, "config", "swerve_drive.yaml")
    rviz_cfg = os.path.join(share, "rviz", "rover.rviz")

    env = [
        SetEnvironmentVariable(
            "GZ_SIM_RESOURCE_PATH",
            os.pathsep.join([os.path.dirname(share)] + [os.environ.get("GZ_SIM_RESOURCE_PATH", "")])),
        SetEnvironmentVariable(
            "GZ_SIM_SYSTEM_PLUGIN_PATH",
            os.pathsep.join([os.environ.get("GZ_SIM_SYSTEM_PLUGIN_PATH", ""),
                             os.environ.get("LD_LIBRARY_PATH", "")])),
    ]

    # slam: the camera matches the RealSense profile used on the real robot (640x480)
    xacro_cmd = [FindExecutable(name="xacro"), " ", os.path.join(share, "urdf", "rover.urdf.xacro"),
                 " controllers_file:=", controllers]
    if slam:
        xacro_cmd += [" camera_width:=640 camera_height:=480 camera_rate:=%s" % lc("camera_rate")]
    robot_description = ParameterValue(Command(xacro_cmd), value_type=str)
    rsp = Node(package="robot_state_publisher", executable="robot_state_publisher", output="screen",
               parameters=[{"robot_description": robot_description, "use_sim_time": True}])

    gz_launch = os.path.join(ros_gz, "launch", "gz_sim.launch.py")
    gz_args = ("-r -v 2 " if flag("gui") else "-r -s -v 2 ") + world_tmp
    gazebo = IncludeLaunchDescription(PythonLaunchDescriptionSource(gz_launch),
                                      launch_arguments={"gz_args": gz_args}.items())

    spawn = Node(package="ros_gz_sim", executable="create", output="screen",
                 arguments=["-topic", "robot_description", "-name", "rover", "-world", world_name,
                            "-x", lc("x"), "-y", lc("y"), "-z", "0.05", "-Y", lc("yaw")])

    # ------------------------------------------------------------------ bridge
    # point cloud: RealSense topic name in slam mode, /camera/points otherwise (what nav2_params.yaml reads)
    points_ros = "/camera/camera/depth/color/points" if slam else "/camera/points"
    bridge = Node(package="ros_gz_bridge", executable="parameter_bridge", output="screen",
                  arguments=[
                      "/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock",
                      "/imu/data@sensor_msgs/msg/Imu[gz.msgs.IMU",
                      "/camera/image@sensor_msgs/msg/Image[gz.msgs.Image",
                      "/camera/depth_image@sensor_msgs/msg/Image[gz.msgs.Image",
                      "/camera/camera_info@sensor_msgs/msg/CameraInfo[gz.msgs.CameraInfo",
                      "/camera/points@sensor_msgs/msg/PointCloud2[gz.msgs.PointCloudPacked",
                  ],
                  remappings=[("/camera/points", points_ros)] if slam else [],
                  parameters=[{"use_sim_time": True}])

    def spawner(name):
        return Node(package="controller_manager", executable="spawner", output="screen",
                    arguments=[name, "--controller-manager", "/controller_manager",
                               "--controller-manager-timeout", "60"],
                    parameters=[{"use_sim_time": True}])

    jsb, wheels, pivots = (spawner(n) for n in ("joint_state_broadcaster", "wheel_velocity_controller",
                                                "pivot_velocity_controller"))

    # ------------------------------------------------------------------ who owns odom -> base_footprint?
    #   no slam / slam+wheel : EKF (wheel odom + IMU), or the swerve node itself if robot_localization is missing
    #   slam+visual          : RTAB-Map visual odometry (EKF and swerve TF are switched off)
    visual = slam and odom_mode == "visual"
    have_ekf = have_pkg("robot_localization") and not visual
    if not visual and not have_ekf:
        print("[sim.launch] robot_localization not installed -> using raw wheel odometry "
              "(sudo apt install ros-humble-robot-localization to enable IMU fusion)")

    swerve_script = os.path.join(get_package_prefix(PKG), "lib", PKG, "swerve_drive_node.py")
    swerve_cmd = ["python3", swerve_script, "--ros-args", "-r", "__node:=swerve_drive", "--params-file", swerve_yaml]
    if have_ekf or visual:
        swerve_cmd += ["-p", "publish_tf:=false", "-p", "odom_topic:=wheel_odom"]
    swerve = ExecuteProcess(cmd=swerve_cmd, output="screen")

    after_pivots = [swerve]
    if have_ekf:
        after_pivots.append(Node(package="robot_localization", executable="ekf_node", name="ekf_filter_node",
                                 output="screen", parameters=[os.path.join(share, "config", "ekf.yaml")],
                                 remappings=[("odometry/filtered", "odom")]))

    # ------------------------------------------------------------------ SLAM (friend's RealSense workflow)
    if slam:
        for pkg in ("rtabmap_launch", "pointcloud_to_laserscan"):
            if not have_pkg(pkg):
                raise RuntimeError("slam:=true needs ros-humble-%s (sudo apt install ros-humble-%s)"
                                   % (pkg.replace("_", "-"), pkg.replace("_", "-")))
        after_pivots.append(ExecuteProcess(
            cmd=["python3", os.path.join(get_package_prefix(PKG), "lib", PKG, "camera_relay.py")],
            output="screen"))

        # identical to the real-robot commands except: sim time, frame_id (base_footprint = odom child here)
        rtab_args = "--Grid/RangeMax 4.0 --Grid/CellSize 0.05 --Grid/MaxObstacleHeight 1.5"
        rtab_args = ("-localization " if localization else "--delete_db_on_start ") + rtab_args
        rtab = {
            "frame_id": "base_footprint",
            "odom_frame_id": "odom",
            "rgb_topic": "/camera/camera/color/image_raw",
            "depth_topic": "/camera/camera/aligned_depth_to_color/image_raw",
            "camera_info_topic": "/camera/camera/color/camera_info",
            "approx_sync": "true", "qos": "1", "queue_size": "30", "wait_imu_to_init": "false",
            "use_sim_time": "true", "rtabmap_viz": lc("rtabmap_viz"), "rviz": "false",
            "database_path": lc("database_path"), "args": rtab_args,
        }
        if not visual:                      # use our wheel+IMU odometry instead of RTAB-Map's visual odometry
            rtab.update({"visual_odometry": "false", "odom_topic": "/odom"})
        after_pivots.append(IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rtabmap_launch"),
                                                       "launch", "rtabmap.launch.py")),
            launch_arguments=rtab.items()))

        after_pivots.append(Node(
            package="pointcloud_to_laserscan", executable="pointcloud_to_laserscan_node", name="pointcloud_to_laserscan",
            output="screen",
            remappings=[("cloud_in", "/camera/camera/depth/color/points"), ("scan", "/scan")],
            parameters=[{"target_frame": "base_link", "min_height": 0.05, "max_height": 0.5,
                         "range_min": 0.3, "range_max": 4.0, "use_inf": True,
                         "transform_tolerance": 0.1, "use_sim_time": True}]))

    if nav2_on:
        after_pivots.append(IncludeLaunchDescription(
            PythonLaunchDescriptionSource(os.path.join(share, "launch", "nav2.launch.py")),
            launch_arguments={"slam": "true" if slam else "false",
                              "odom_topic": "/rtabmap/odom" if visual else "/odom"}.items()))

    rviz = Node(package="rviz2", executable="rviz2", arguments=["-d", rviz_cfg], output="screen",
                parameters=[{"use_sim_time": True}], condition=IfCondition(LaunchConfiguration("rviz")))

    chain = [
        RegisterEventHandler(OnProcessExit(target_action=spawn, on_exit=[jsb])),
        RegisterEventHandler(OnProcessExit(target_action=jsb, on_exit=[wheels])),
        RegisterEventHandler(OnProcessExit(target_action=wheels, on_exit=[pivots])),
        RegisterEventHandler(OnProcessExit(target_action=pivots, on_exit=after_pivots)),
    ]
    return env + [rsp, gazebo, spawn, bridge, rviz] + chain


def generate_launch_description():
    D = DeclareLaunchArgument
    return LaunchDescription([
        D("world", default_value="obstacles", description="'obstacles', 'textured', or a path to an .sdf"),
        D("world_name", default_value="", description="<world name=...> inside the file (default: file name)"),
        D("gui", default_value="true", description="Gazebo GUI (false = server only)"),
        D("rviz", default_value="true"),
        D("nav2", default_value="false", description="also start Nav2"),
        D("slam", default_value="false", description="RealSense-style camera topics + RTAB-Map + /scan; Nav2 uses the map"),
        D("odom_mode", default_value="wheel", description="slam only: 'wheel' (EKF wheel+IMU odom) or 'visual' (RTAB-Map)"),
        D("localization", default_value="false", description="slam only: reuse database_path instead of a new map"),
        D("database_path", default_value=os.path.expanduser("~/rover_sim_rtabmap.db")),
        D("rtabmap_viz", default_value="false"),
        D("camera_rate", default_value="15", description="slam only: camera Hz (the real camera does 30)"),
        D("x", default_value="0.0"), D("y", default_value="0.0"), D("yaw", default_value="0.0"),
        OpaqueFunction(function=setup),
    ])
