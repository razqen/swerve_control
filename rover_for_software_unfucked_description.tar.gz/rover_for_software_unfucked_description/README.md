# rover_for_software_unfucked_description — ROS 2 Humble + Gazebo Fortress

Replaces the ROS 1 catkin package from the Fusion export (delete the old `urdf/*.trans`, `urdf/*.gazebo`,
`urdf/materials.xacro`, `urdf/rover_for_software_unfucked.xacro`, `launch/*.launch`, `launch/controller.yaml`,
`launch/urdf.rviz`; keep `meshes/` untouched).

## Install deps (Ubuntu 22.04)
```
sudo apt install ros-humble-ros-ign-gazebo ros-humble-ros-ign-bridge ros-humble-ign-ros2-control \
  ros-humble-ros2-controllers ros-humble-controller-manager ros-humble-xacro ros-humble-joint-state-publisher-gui \
  ros-humble-nav2-bringup ros-humble-navigation2 ros-humble-rviz2
```
## Build / run
```
cd ~/ws && colcon build --symlink-install --packages-select rover_for_software_unfucked_description
source install/setup.bash
ros2 launch rover_for_software_unfucked_description display.launch.py          # RViz + joint sliders only
ros2 launch rover_for_software_unfucked_description sim.launch.py              # Gazebo + RViz
ros2 launch rover_for_software_unfucked_description sim.launch.py nav2:=true   # + Nav2
```
Drive: `ros2 run teleop_twist_keyboard teleop_twist_keyboard` (hold `shift` + `j`/`l` for strafe) or
`ros2 topic pub -r 10 /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.3, y: 0.2}, angular: {z: 0.0}}"`.
Nav2: send a goal with RViz's "Nav2 Goal"/"2D Goal Pose" tool (fixed frame `odom`).

## Frames
`odom -> base_footprint -> base_link -> chassis_link (Fusion origin, rotated +90deg) -> sus arms -> pivots -> wheels`
base_link = centre of the 4 wheels at axle height, x forward / y left / z up. The `odom -> base_footprint`
TF comes from the swerve node (wheel/steer dead reckoning); `map -> odom` is a static identity when Nav2 runs.

## Joints
| Fusion name | New name | Type | Notes |
|---|---|---|---|
| Revolute 1 / 2 | left_sus_arm_joint / right_sus_arm_joint | revolute, passive | +-25deg, damping 30, friction 5 (xacro props). Axes mirror each other (as exported). State only, no command |
| Revolute 3 / 4 / 5 / 6 | front_left / back_left / back_right / front_right _pivot_joint | revolute +-90deg | velocity-commanded; node closes the angle loop. Axis -z => steer angle (CCW+) = -joint position |
| Revolute 7 / 8 / 9 / 10 | front_left / back_left / back_right / front_right _wheel_joint | continuous | velocity-commanded. Fusion mirrored the right axes => +vel = forward on left, backward on right |
Sign handling lives in `config/swerve_drive.yaml` (`wheel_sign`, `pivot_sign`); joint order is FL, FR, BL, BR.

## Interfaces
- `/cmd_vel` (Twist: vx, vy, wz) -> `swerve_drive` -> `/wheel_velocity_controller/commands`, `/pivot_velocity_controller/commands` (Float64MultiArray)
- `/joint_states`, `/odom`, `/imu/data`, `/camera/{image,depth_image,camera_info,points}` (points are in `camera_link`)

## Changes vs the export
Joint names (no spaces), chassis link renamed `chassis_link`, ROS-oriented `base_link`/`base_footprint` added, wheel
collision = cylinder (r 0.1025, w 0.11) with mu 1.0, passive limits/damping on the arms, +-90deg limits on pivots,
IMU + depth camera added. Inertials, mesh offsets and joint origins are unchanged.

## RTAB-Map + laserscan mode (`slam:=true`)

Reproduces the RealSense -> RTAB-Map -> `pointcloud_to_laserscan` -> Nav2 (static map, no AMCL) workflow in the sim.

```
sudo apt install ros-humble-rtabmap-ros ros-humble-pointcloud-to-laserscan ros-humble-robot-localization
ros2 launch rover_for_software_unfucked_description sim.launch.py world:=textured slam:=true nav2:=true
```

* `odom_mode:=wheel` (default): RTAB-Map uses the wheel+IMU EKF odometry (`/odom`) and only publishes `map -> odom` and the map.
* `odom_mode:=visual`: RTAB-Map visual odometry owns `odom -> base_footprint` (EKF and swerve TF are off); Nav2 reads `/rtabmap/odom`.
* `localization:=true`: reuse `database_path` (default `~/rover_sim_rtabmap.db`) instead of starting a new map.
* The sim camera publishes the RealSense topic names (`/camera/camera/color/image_raw`,
  `/camera/camera/aligned_depth_to_color/image_raw`, `/camera/camera/color/camera_info`,
  `/camera/camera/depth/color/points`) at 640x480; images are re-stamped with `camera_optical_frame` by `camera_relay.py`.
* Differences from the hardware commands: `use_sim_time:=true`, `frame_id:=base_footprint` (the sim's odom child),
  camera mounted at z = 0.39 m instead of 0.2 m, `transform_tolerance` 0.1 on the laserscan node.
* Nav2 uses `config/nav2_params_slam.yaml`: global costmap = static_layer on `/rtabmap/map` + inflation 0.4,
  local costmap = `/scan` obstacle layer.  Save the map with
  `ros2 run nav2_map_server map_saver_cli -f ~/my_map --ros-args -r map:=/rtabmap/map`.
* `world:=textured` is a 20x20 m walled arena with generated textures (visual SLAM needs surface detail).
