#!/usr/bin/env python3
"""4-wheel independent-steering ("swerve") kinematics node.

  /cmd_vel (Twist: vx, vy, wz in base_link)
      -> /wheel_velocity_controller/commands  (Float64MultiArray, rad/s)
      -> /pivot_velocity_controller/commands  (Float64MultiArray, rad/s; angle loop closed here)
  /joint_states
      -> /odom (nav_msgs/Odometry) and TF  odom -> base_footprint   (wheel/steer dead-reckoning)

Joint order everywhere:  front_left, front_right, back_left, back_right
Sign conventions come from the Fusion export and are parameters (see config/swerve_drive.yaml):
  wheel_sign : +1 if positive joint velocity drives the rover along the wheel heading (left wheels: -1, right: +1)
  pivot_sign : steering angle (CCW positive, REP-103) = pivot_sign * pivot joint position
"""
import math

import numpy as np
import rclpy
from geometry_msgs.msg import Twist, TransformStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from tf2_ros import TransformBroadcaster

CORNERS = ["front_left", "front_right", "back_left", "back_right"]


def wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


class SwerveDrive(Node):
    def __init__(self):
        super().__init__("swerve_drive")
        d = self.declare_parameter
        self.r = d("wheel_radius", 0.1025).value
        xs = d("wheel_x", [0.38885, 0.38885, -0.38885, -0.38885]).value
        ys = d("wheel_y", [0.237595, -0.237595, 0.237595, -0.237595]).value
        self.pos = list(zip(xs, ys))
        self.wheel_sign = list(d("wheel_sign", [-1.0, 1.0, -1.0, 1.0]).value)
        self.pivot_sign = list(d("pivot_sign", [-1.0, -1.0, -1.0, -1.0]).value)
        self.wheel_joints = list(d("wheel_joints", [f"{c}_wheel_joint" for c in CORNERS]).value)
        self.pivot_joints = list(d("pivot_joints", [f"{c}_pivot_joint" for c in CORNERS]).value)
        self.max_steer = d("max_steer_angle", 1.55).value        # rad, a bit inside the +-pi/2 URDF limit
        self.steer_kp = d("steer_kp", 6.0).value                  # 1/s
        self.max_steer_rate = d("max_steer_rate", 2.5).value      # rad/s
        self.max_wheel_speed = d("max_wheel_speed", 12.0).value   # rad/s  (~1.2 m/s)
        self.cmd_timeout = d("cmd_timeout", 0.5).value            # s
        self.min_speed = d("min_wheel_speed_for_steer", 0.02).value  # m/s, below this keep last steer angle
        self.base_frame = d("base_frame", "base_footprint").value
        self.odom_frame = d("odom_frame", "odom").value
        self.publish_tf = d("publish_tf", True).value
        odom_topic = d("odom_topic", "odom").value   # "wheel_odom" when the EKF fuses it with the IMU
        rate = d("rate", 50.0).value

        self.cmd = (0.0, 0.0, 0.0)
        self.cmd_stamp = self.get_clock().now()
        self.steer = [0.0] * 4          # measured steering angle (REP-103)
        self.wheel_w = [0.0] * 4        # measured wheel angular velocity (rad/s, signed to heading)
        self.target_steer = [0.0] * 4   # last commanded steering angle (held when stopped)
        self.have_js = False
        self.x = self.y = self.yaw = 0.0
        self.last_odom_t = None

        self.create_subscription(Twist, "cmd_vel", self.on_cmd, 10)
        self.create_subscription(JointState, "joint_states", self.on_js, 20)
        self.wheel_pub = self.create_publisher(Float64MultiArray, "wheel_velocity_controller/commands", 10)
        self.pivot_pub = self.create_publisher(Float64MultiArray, "pivot_velocity_controller/commands", 10)
        self.odom_pub = self.create_publisher(Odometry, odom_topic, 10)
        self.tf_br = TransformBroadcaster(self)
        self.create_timer(1.0 / rate, self.on_timer)
        self.get_logger().info("swerve_drive ready (wheel order: %s)" % ", ".join(CORNERS))

    # ------------------------------------------------------------------ inputs
    def on_cmd(self, msg: Twist):
        self.cmd = (msg.linear.x, msg.linear.y, msg.angular.z)
        self.cmd_stamp = self.get_clock().now()

    def on_js(self, msg: JointState):
        idx = {n: i for i, n in enumerate(msg.name)}
        try:
            for k in range(4):
                self.steer[k] = self.pivot_sign[k] * msg.position[idx[self.pivot_joints[k]]]
                self.wheel_w[k] = self.wheel_sign[k] * msg.velocity[idx[self.wheel_joints[k]]]
        except (KeyError, IndexError):
            return
        self.have_js = True

    # ------------------------------------------------------------------ control
    def on_timer(self):
        now = self.get_clock().now()
        vx, vy, wz = self.cmd
        if (now - self.cmd_stamp).nanoseconds * 1e-9 > self.cmd_timeout:
            vx = vy = wz = 0.0

        wheel_cmd, pivot_cmd = [0.0] * 4, [0.0] * 4
        for k, (px, py) in enumerate(self.pos):
            wvx, wvy = vx - wz * py, vy + wz * px           # velocity of the wheel contact point
            speed = math.hypot(wvx, wvy)
            if speed > self.min_speed:
                ang = math.atan2(wvy, wvx)
                # two equivalent solutions: (ang, +speed) or (ang +- pi, -speed); take the one in range
                # that is closest to the current steering angle.
                cands = [(ang, speed), (wrap(ang + math.pi), -speed)]
                cands = [c for c in cands if abs(c[0]) <= self.max_steer + 1e-9] or \
                        [(max(-self.max_steer, min(self.max_steer, c[0])), c[1]) for c in cands]
                ang, speed = min(cands, key=lambda c: abs(c[0] - self.steer[k]))
                self.target_steer[k] = ang
            else:
                speed = 0.0
            err = wrap(self.target_steer[k] - self.steer[k])
            # don't drive while the wheel is still swinging round (avoids scrubbing)
            drive = speed * max(0.0, math.cos(err)) ** 3 if speed != 0.0 else 0.0
            w = drive / self.r
            wheel_cmd[k] = self.wheel_sign[k] * max(-self.max_wheel_speed, min(self.max_wheel_speed, w))
            rate = max(-self.max_steer_rate, min(self.max_steer_rate, self.steer_kp * err))
            pivot_cmd[k] = self.pivot_sign[k] * rate

        self.wheel_pub.publish(Float64MultiArray(data=wheel_cmd))
        self.pivot_pub.publish(Float64MultiArray(data=pivot_cmd))
        self.update_odom(now)

    # ------------------------------------------------------------------ odometry
    def update_odom(self, now):
        if not self.have_js:
            return
        # each wheel measures a velocity vector at its contact point:
        #   vx - wz*y = w cos(delta) ;  vy + wz*x = w sin(delta)   -> least squares for (vx, vy, wz)
        A, b = [], []
        for k, (px, py) in enumerate(self.pos):
            v = self.wheel_w[k] * self.r
            A += [[1, 0, -py], [0, 1, px]]
            b += [v * math.cos(self.steer[k]), v * math.sin(self.steer[k])]
        vx, vy, wz = np.linalg.lstsq(np.array(A), np.array(b), rcond=None)[0]

        t = now.nanoseconds * 1e-9
        if self.last_odom_t is not None:
            dt = t - self.last_odom_t
            if 0.0 < dt < 1.0:
                yaw_mid = self.yaw + 0.5 * wz * dt
                self.x += (vx * math.cos(yaw_mid) - vy * math.sin(yaw_mid)) * dt
                self.y += (vx * math.sin(yaw_mid) + vy * math.cos(yaw_mid)) * dt
                self.yaw = wrap(self.yaw + wz * dt)
        self.last_odom_t = t

        stamp = now.to_msg()
        qz, qw = math.sin(self.yaw / 2), math.cos(self.yaw / 2)
        od = Odometry()
        od.header.stamp = stamp
        od.header.frame_id = self.odom_frame
        od.child_frame_id = self.base_frame
        od.pose.pose.position.x, od.pose.pose.position.y = self.x, self.y
        od.pose.pose.orientation.z, od.pose.pose.orientation.w = qz, qw
        od.twist.twist.linear.x, od.twist.twist.linear.y, od.twist.twist.angular.z = vx, vy, wz
        cov = [0.0] * 36
        for i, v in zip((0, 7, 35), (1e-3, 1e-3, 1e-2)):
            cov[i] = v
        od.pose.covariance = cov
        od.twist.covariance = cov
        self.odom_pub.publish(od)

        if self.publish_tf:
            tf = TransformStamped()
            tf.header.stamp = stamp
            tf.header.frame_id = self.odom_frame
            tf.child_frame_id = self.base_frame
            tf.transform.translation.x, tf.transform.translation.y = self.x, self.y
            tf.transform.rotation.z, tf.transform.rotation.w = qz, qw
            self.tf_br.sendTransform(tf)


def main():
    rclpy.init()
    node = SwerveDrive()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
