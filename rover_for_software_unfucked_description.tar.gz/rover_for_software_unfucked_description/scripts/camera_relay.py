#!/usr/bin/env python3
"""Make the Gazebo RGB-D camera look like the Intel RealSense ROS 2 driver.

Gazebo stamps the images with the point-cloud frame (camera_link, x forward).  RealSense-style consumers
(rtabmap, depth_image_proc ...) expect the images in an *optical* frame (z forward), so this node re-publishes
the images with header.frame_id = camera_optical_frame and the RealSense topic names:

  /camera/image        -> /camera/camera/color/image_raw
  /camera/depth_image  -> /camera/camera/aligned_depth_to_color/image_raw   (Gazebo depth is already colour-aligned)
  /camera/camera_info  -> /camera/camera/color/camera_info (+ aligned_depth_to_color/camera_info)
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CameraInfo, Image


class CameraRelay(Node):
    def __init__(self):
        super().__init__("camera_relay")
        self.frame = self.declare_parameter("optical_frame", "camera_optical_frame").value
        p = "/camera/camera/"
        self.pubs = {
            "color": self.create_publisher(Image, p + "color/image_raw", 10),
            "depth": self.create_publisher(Image, p + "aligned_depth_to_color/image_raw", 10),
            "info": self.create_publisher(CameraInfo, p + "color/camera_info", 10),
            "dinfo": self.create_publisher(CameraInfo, p + "aligned_depth_to_color/camera_info", 10),
        }
        self.create_subscription(Image, "/camera/image", lambda m: self.fwd(m, "color"), 10)
        self.create_subscription(Image, "/camera/depth_image", lambda m: self.fwd(m, "depth"), 10)
        self.create_subscription(CameraInfo, "/camera/camera_info", self.fwd_info, 10)
        self.get_logger().info("relaying Gazebo camera -> RealSense topic names (frame %s)" % self.frame)

    def fwd(self, msg, key):
        msg.header.frame_id = self.frame
        self.pubs[key].publish(msg)

    def fwd_info(self, msg):
        msg.header.frame_id = self.frame
        self.pubs["info"].publish(msg)
        self.pubs["dinfo"].publish(msg)


def main():
    rclpy.init()
    node = CameraRelay()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()


if __name__ == "__main__":
    main()
